# Daily Water Routine Calculator

This project includes 3 HTML-based calculators:
- 💧 Daily Water Intake Calculator
- 🏃‍♂️ Activity & Temperature Adjustment Calculator
- ⏰ Hydration Timer Generator

## How to deploy on Vercel
1. Fork or clone this repository.
2. Go to https://vercel.com and import the project.
3. Deploy using default settings (Static Site).
